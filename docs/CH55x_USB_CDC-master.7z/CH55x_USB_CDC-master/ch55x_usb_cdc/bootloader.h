#ifndef __BOOTLOADER_H
#define __BOOTLOADER_H

#define BOOT_ADDR  0x3800

void JumpToBootloader(void);

#endif
