#ifndef	__DELAY_H__
#define __DELAY_H__

#include "ch554_platform.h"

void	mDelayuS(uint16_t n );
void	mDelaymS(uint16_t n );

#endif
